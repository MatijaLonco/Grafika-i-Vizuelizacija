import React, { useEffect, useRef, useState } from 'react';

interface TimerProps {
  running: boolean;
  onTick?: (seconds: number) => void;
  externalSeconds?: number;
}

export function Timer({ running, onTick, externalSeconds }: TimerProps) {
  const [seconds, setSeconds] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds((s) => {
          const next = s + 1;
          onTick?.(next);
          return next;
        });
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running]);

  const display = externalSeconds !== undefined ? externalSeconds : seconds;
  const mins = Math.floor(display / 60).toString().padStart(2, '0');
  const secs = (display % 60).toString().padStart(2, '0');

  return (
    <div className="timer-display">
      {mins}:{secs}
    </div>
  );
}

export function useTimer(running: boolean) {
  const [seconds, setSeconds] = useState(0);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    if (running) {
      intervalRef.current = setInterval(() => {
        setSeconds((s) => s + 1);
      }, 1000);
    } else {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [running]);

  const reset = () => setSeconds(0);

  return { seconds, reset };
}
