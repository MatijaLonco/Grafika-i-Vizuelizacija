import React from 'react';
import type { PuzzleGrid, GameCellState } from '../types';

interface KakuroGridProps {
  grid: PuzzleGrid;
  cellStates: (GameCellState | null)[][];
  onCellClick: (row: number, col: number) => void;
  isComplete: boolean;
}

function ClueCell({ right, down }: { right?: number; down?: number }) {
  const hasRight = right !== undefined;
  const hasDown = down !== undefined;

  return (
    <div className="w-full h-full relative bg-[hsl(20,20%,22%)] overflow-hidden">
      {/* Diagonal separator line */}
      <svg
        className="absolute inset-0 w-full h-full pointer-events-none"
        viewBox="0 0 54 54"
        preserveAspectRatio="none"
      >
        {/* Thin shadow line */}
        <line x1="1" y1="53" x2="53" y2="1" stroke="hsl(20,20%,12%)" strokeWidth="2.5" />
        {/* Main line */}
        <line x1="1" y1="53" x2="53" y2="1" stroke="hsl(35,35%,48%)" strokeWidth="1.5" />
      </svg>

      {/* DOWN number — top-left triangle */}
      {hasDown && (
        <div
          className="absolute flex items-center justify-center"
          style={{
            top: 2,
            left: 3,
            width: 22,
            height: 22,
          }}
        >
          <span
            style={{
              fontSize: down >= 10 ? 10 : 12,
              fontWeight: 900,
              color: 'hsl(200,70%,75%)',
              lineHeight: 1,
              letterSpacing: '-0.5px',
            }}
          >
            {down}
          </span>
        </div>
      )}

      {/* RIGHT number — bottom-right triangle */}
      {hasRight && (
        <div
          className="absolute flex items-center justify-center"
          style={{
            bottom: 2,
            right: 3,
            width: 22,
            height: 22,
          }}
        >
          <span
            style={{
              fontSize: right >= 10 ? 10 : 12,
              fontWeight: 900,
              color: 'hsl(35,90%,78%)',
              lineHeight: 1,
              letterSpacing: '-0.5px',
            }}
          >
            {right}
          </span>
        </div>
      )}
    </div>
  );
}

export function KakuroGrid({ grid, cellStates, onCellClick, isComplete }: KakuroGridProps) {
  return (
    <div className="overflow-auto">
      <table className="kakuro-grid">
        <tbody>
          {grid.map((row, r) => (
            <tr key={r}>
              {row.map((cell, c) => {
                if (cell.type === 'block') {
                  return (
                    <td key={c} className="kakuro-cell kakuro-cell-block p-0" />
                  );
                }

                if (cell.type === 'clue') {
                  return (
                    <td key={c} className="kakuro-cell p-0" style={{ background: 'hsl(20,20%,22%)' }}>
                      <ClueCell right={cell.right} down={cell.down} />
                    </td>
                  );
                }

                // White cell
                const state = cellStates[r][c];
                const isActive = state?.isActive ?? false;
                const isHighlighted = state?.highlighted ?? false;
                const isHinted = state?.isHinted ?? false;
                const value = state?.value ?? null;

                let cellClass = 'kakuro-cell kakuro-cell-white p-0';
                if (isComplete) {
                  cellClass += ' correct';
                } else if (isActive) {
                  cellClass += ' active';
                } else if (isHinted) {
                  cellClass += ' hinted';
                } else if (isHighlighted) {
                  cellClass += ' highlighted';
                }

                return (
                  <td
                    key={c}
                    className={cellClass}
                    onClick={() => onCellClick(r, c)}
                  >
                    <div className="w-full h-full flex items-center justify-center">
                      {value !== null && (
                        <span className="cell-value">{value}</span>
                      )}
                    </div>
                  </td>
                );
              })}
            </tr>
          ))}
        </tbody>
      </table>

      {/* Legend */}
      <div className="flex items-center gap-4 mt-2 px-1">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm" style={{ background: 'hsl(200,70%,75%)' }} />
          <span className="text-xs text-gray-500">↓ prema dolje</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm" style={{ background: 'hsl(35,90%,78%)' }} />
          <span className="text-xs text-gray-500">→ prema desno</span>
        </div>
      </div>
    </div>
  );
}
