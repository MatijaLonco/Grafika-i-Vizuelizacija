import React, { useContext } from 'react';
import { SoundCtx } from '../App';
import { playSfxClick } from '../audio/music';

interface Button3DProps {
  children: React.ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'accent' | 'danger' | 'ghost';
  size?: 'sm' | 'md' | 'lg' | 'xl';
  disabled?: boolean;
  className?: string;
  fullWidth?: boolean;
}

const variantStyles: Record<string, string> = {
  primary: 'bg-red-600 text-white hover:bg-red-700',
  secondary: 'bg-amber-100 text-amber-900 hover:bg-amber-200',
  accent: 'bg-sky-600 text-white hover:bg-sky-700',
  danger: 'bg-red-700 text-white hover:bg-red-800',
  ghost: 'bg-white text-gray-700 hover:bg-gray-50 border-2 border-gray-300',
};

const sizeStyles: Record<string, string> = {
  sm: 'px-4 py-1.5 text-sm rounded-lg',
  md: 'px-6 py-2.5 text-base rounded-xl',
  lg: 'px-8 py-3.5 text-lg rounded-xl',
  xl: 'px-10 py-4 text-xl rounded-2xl min-w-[200px]',
};

export function Button3D({
  children,
  onClick,
  variant = 'primary',
  size = 'md',
  disabled = false,
  className = '',
  fullWidth = false,
}: Button3DProps) {
  const sound = useContext(SoundCtx);

  const handleClick = () => {
    if (sound.sfxEnabled) playSfxClick();
    onClick?.();
  };

  return (
    <button
      className={`btn-3d ${variantStyles[variant]} ${sizeStyles[size]} ${fullWidth ? 'w-full' : ''} ${className}`}
      onClick={handleClick}
      disabled={disabled}
    >
      {children}
    </button>
  );
}
