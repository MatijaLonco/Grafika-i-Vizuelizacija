import React, { useState, useCallback, useEffect, useRef } from 'react';
import { MainMenu } from './pages/MainMenu';
import { HowToPlay } from './pages/HowToPlay';
import { SoundSettingsPage } from './pages/SoundSettings';
import { ModeSelect } from './pages/ModeSelect';
import { DifficultySelect } from './pages/DifficultySelect';
import { GameScreen } from './pages/GameScreen';
import { GameComplete } from './pages/GameComplete';
import { TwoPlayerResult } from './pages/TwoPlayerResult';
import type { Screen, Difficulty, SoundSettings } from './types';
import { startMusic, stopMusic, setMusicVolume } from './audio/music';

export const SoundCtx = React.createContext<SoundSettings>({
  musicEnabled: true,
  sfxEnabled: true,
  volume: 70,
});

export default function App() {
  const [screen, setScreen] = useState<Screen>('main-menu');
  const [difficulty, setDifficulty] = useState<Difficulty | null>(null);
  const [isTwoPlayer, setIsTwoPlayer] = useState(false);
  const [soundSettings, setSoundSettings] = useState<SoundSettings>({
    musicEnabled: true,
    sfxEnabled: true,
    volume: 70,
  });
  const musicStarted = useRef(false);

  // Start music on first user interaction
  useEffect(() => {
    const handleInteraction = () => {
      if (!musicStarted.current) {
        musicStarted.current = true;
        if (soundSettings.musicEnabled) {
          startMusic(soundSettings.volume);
        }
      }
    };
    window.addEventListener('click', handleInteraction, { once: true });
    window.addEventListener('keydown', handleInteraction, { once: true });
    return () => {
      window.removeEventListener('click', handleInteraction);
      window.removeEventListener('keydown', handleInteraction);
    };
  }, [soundSettings.musicEnabled, soundSettings.volume]);

  // React to music setting changes
  useEffect(() => {
    if (!musicStarted.current) return;
    if (soundSettings.musicEnabled) {
      startMusic(soundSettings.volume);
    } else {
      stopMusic();
    }
  }, [soundSettings.musicEnabled]);

  // React to volume changes
  useEffect(() => {
    if (!musicStarted.current) return;
    setMusicVolume(soundSettings.volume);
  }, [soundSettings.volume]);

  // 1-player game results
  const [gameSeconds, setGameSeconds] = useState(0);
  const [gameScore, setGameScore] = useState(0);
  const [gameHints, setGameHints] = useState(0);
  const [totalScore, setTotalScore] = useState(0);

  // 2-player results
  const [p1Seconds, setP1Seconds] = useState(0);
  const [p1Hints, setP1Hints] = useState(0);
  const [p2Seconds, setP2Seconds] = useState(0);
  const [p2Hints, setP2Hints] = useState(0);

  const handleGameComplete = useCallback(
    (seconds: number, score: number, hintsUsed: number) => {
      if (isTwoPlayer && screen === 'two-player-p1') {
        setP1Seconds(seconds);
        setP1Hints(hintsUsed);
        setTimeout(() => setScreen('two-player-p2'), 1200);
      } else if (isTwoPlayer && screen === 'two-player-p2') {
        setP2Seconds(seconds);
        setP2Hints(hintsUsed);
        setTimeout(() => setScreen('two-player-result'), 1200);
      } else {
        setGameSeconds(seconds);
        setGameScore(score);
        setGameHints(hintsUsed);
        setTotalScore((prev) => prev + score);
        setTimeout(() => setScreen('game-complete'), 1200);
      }
    },
    [isTwoPlayer, screen]
  );

  const goToMainMenu = useCallback(() => {
    setScreen('main-menu');
    setIsTwoPlayer(false);
    setDifficulty(null);
  }, []);

  const handlePlayAgain = useCallback(() => {
    if (isTwoPlayer) {
      setP1Seconds(0);
      setP1Hints(0);
      setP2Seconds(0);
      setP2Hints(0);
    }
    setScreen('difficulty-select');
  }, [isTwoPlayer]);

  return (
    <SoundCtx.Provider value={soundSettings}>
      {screen === 'main-menu' && (
        <MainMenu
          onStart={() => setScreen('mode-select')}
          onSoundSettings={() => setScreen('sound-settings')}
          onHowToPlay={() => setScreen('how-to-play')}
        />
      )}
      {screen === 'how-to-play' && (
        <HowToPlay onBack={() => setScreen('main-menu')} />
      )}
      {screen === 'sound-settings' && (
        <SoundSettingsPage
          settings={soundSettings}
          onChange={setSoundSettings}
          onBack={() => setScreen('main-menu')}
        />
      )}
      {screen === 'mode-select' && (
        <ModeSelect
          onSinglePlayer={() => { setIsTwoPlayer(false); setScreen('difficulty-select'); }}
          onTwoPlayer={() => { setIsTwoPlayer(true); setScreen('difficulty-select'); }}
          onBack={() => setScreen('main-menu')}
        />
      )}
      {screen === 'difficulty-select' && (
        <DifficultySelect
          isTwoPlayer={isTwoPlayer}
          onSelect={(d) => {
            setDifficulty(d);
            setScreen(isTwoPlayer ? 'two-player-p1' : 'game');
          }}
          onBack={() => setScreen('mode-select')}
        />
      )}
      {screen === 'game' && difficulty && (
        <GameScreen
          key="single-game"
          difficulty={difficulty}
          onBack={() => setScreen('difficulty-select')}
          onComplete={handleGameComplete}
        />
      )}
      {screen === 'two-player-p1' && difficulty && (
        <GameScreen
          key="two-player-p1"
          difficulty={difficulty}
          playerLabel="👤 Igrac 1"
          twoPlayerMode
          onBack={() => setScreen('difficulty-select')}
          onComplete={handleGameComplete}
        />
      )}
      {screen === 'two-player-p2' && difficulty && (
        <GameScreen
          key="two-player-p2"
          difficulty={difficulty}
          playerLabel="👤 Igrac 2"
          twoPlayerMode
          onBack={() => setScreen('difficulty-select')}
          onComplete={handleGameComplete}
        />
      )}
      {screen === 'game-complete' && (
        <GameComplete
          seconds={gameSeconds}
          score={gameScore}
          hintsUsed={gameHints}
          totalScore={totalScore}
          onPlayAgain={handlePlayAgain}
          onMainMenu={goToMainMenu}
        />
      )}
      {screen === 'two-player-result' && (
        <TwoPlayerResult
          player1Seconds={p1Seconds}
          player2Seconds={p2Seconds}
          player1Hints={p1Hints}
          player2Hints={p2Hints}
          onPlayAgain={handlePlayAgain}
          onMainMenu={goToMainMenu}
        />
      )}
    </SoundCtx.Provider>
  );
}
