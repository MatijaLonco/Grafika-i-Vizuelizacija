import React, { useState } from 'react';
import { Button3D } from '../components/Button3D';
import { getRandomFunFact } from '../data/funFacts';

interface TwoPlayerResultProps {
  player1Seconds: number;
  player2Seconds: number;
  player1Hints: number;
  player2Hints: number;
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

function formatTime(s: number) {
  return `${Math.floor(s / 60).toString().padStart(2, '0')}:${(s % 60).toString().padStart(2, '0')}`;
}

export function TwoPlayerResult({
  player1Seconds,
  player2Seconds,
  player1Hints,
  player2Hints,
  onPlayAgain,
  onMainMenu,
}: TwoPlayerResultProps) {
  const [funFact] = useState(() => getRandomFunFact());

  const p1wins = player1Seconds <= player2Seconds;
  const tie = player1Seconds === player2Seconds;

  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-pop-in w-full max-w-sm">
        <div className="game-panel p-6 space-y-5 text-center">
          {/* Title */}
          <div>
            <div className="text-4xl mb-2">{tie ? '🤝' : '🏆'}</div>
            <h1 className="text-2xl font-black text-red-600">
              {tie ? 'Neriješeno!' : p1wins ? 'Igrac 1 pobijedio!' : 'Igrac 2 pobijedio!'}
            </h1>
          </div>

          {/* Results comparison */}
          <div className="grid grid-cols-2 gap-3">
            {/* Player 1 */}
            <div className={`rounded-xl p-4 ${p1wins && !tie ? 'bg-green-50 border-2 border-green-400' : 'bg-gray-50 border border-gray-200'}`}>
              <div className="text-sm font-bold text-gray-500 mb-1">👤 Igrac 1</div>
              {p1wins && !tie && <div className="text-xs text-green-600 font-bold mb-1">🏆 Pobjednik!</div>}
              <div className="text-2xl font-black font-mono text-red-600">
                {formatTime(player1Seconds)}
              </div>
              <div className="text-xs text-gray-500 mt-1">
                💡 {player1Hints} hint{player1Hints !== 1 ? 'a' : ''}
              </div>
            </div>

            {/* Player 2 */}
            <div className={`rounded-xl p-4 ${!p1wins && !tie ? 'bg-green-50 border-2 border-green-400' : 'bg-gray-50 border border-gray-200'}`}>
              <div className="text-sm font-bold text-gray-500 mb-1">👤 Igrac 2</div>
              {!p1wins && !tie && <div className="text-xs text-green-600 font-bold mb-1">🏆 Pobjednik!</div>}
              <div className="text-2xl font-black font-mono text-red-600">
                {formatTime(player2Seconds)}
              </div>
              <div className="text-xs text-gray-500 mt-1">
                💡 {player2Hints} hint{player2Hints !== 1 ? 'a' : ''}
              </div>
            </div>
          </div>

          {/* Difference */}
          {!tie && (
            <div className="bg-amber-50 rounded-xl p-3 text-sm">
              <span className="text-gray-600">Razlika: </span>
              <span className="font-black text-amber-700">
                {formatTime(Math.abs(player1Seconds - player2Seconds))}
              </span>
              <span className="text-gray-600"> u korist {p1wins ? 'Igraca 1' : 'Igraca 2'}</span>
            </div>
          )}

          {/* Fun fact */}
          <div className="bg-red-50 border border-red-100 rounded-xl p-4">
            <div className="text-xs font-bold text-red-500 uppercase tracking-wide mb-2">
              🌸 Znate li da...
            </div>
            <p className="text-sm text-gray-700 leading-relaxed text-left">
              {funFact}
            </p>
          </div>

          {/* Buttons */}
          <div className="flex flex-col gap-3">
            <Button3D variant="primary" size="lg" onClick={onPlayAgain} fullWidth>
              🔄 Igraj ponovo
            </Button3D>
            <Button3D variant="ghost" size="md" onClick={onMainMenu} fullWidth>
              🏠 Glavni meni
            </Button3D>
          </div>
        </div>
      </div>
    </div>
  );
}
