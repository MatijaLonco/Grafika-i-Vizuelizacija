import React from 'react';
import { Button3D } from '../components/Button3D';
import { getRandomFunFact } from '../data/funFacts';
import { useState } from 'react';

interface GameCompleteProps {
  seconds: number;
  score: number;
  hintsUsed: number;
  totalScore: number;
  onPlayAgain: () => void;
  onMainMenu: () => void;
}

export function GameComplete({ seconds, score, hintsUsed, totalScore, onPlayAgain, onMainMenu }: GameCompleteProps) {
  const [funFact] = useState(() => getRandomFunFact());

  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = (seconds % 60).toString().padStart(2, '0');

  const stars = Array.from({ length: 3 }, (_, i) => i < score);

  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-pop-in w-full max-w-sm">
        <div className="game-panel p-6 space-y-5 text-center">
          {/* Title */}
          <div>
            <div className="text-4xl mb-2">🎌</div>
            <h1 className="text-2xl font-black text-red-600">Bravo! Riješeno!</h1>
          </div>

          {/* Stars */}
          <div className="flex justify-center gap-2 text-4xl">
            {stars.map((lit, i) => (
              <span
                key={i}
                className={`transition-transform duration-300 ${lit ? 'star-gold scale-110' : 'star-empty'}`}
                style={{ animationDelay: `${i * 100}ms` }}
              >
                ⭐
              </span>
            ))}
          </div>

          {/* Stats */}
          <div className="bg-amber-50 rounded-xl p-4 space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-gray-600">Vrijeme</span>
              <span className="font-black font-mono text-red-600">{mins}:{secs}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-600">Hintovi korišćeni</span>
              <span className="font-black text-amber-600">{hintsUsed}</span>
            </div>
            <div className="flex justify-between border-t border-amber-200 pt-2">
              <span className="font-bold text-gray-700">Poeni za ovu igru</span>
              <span className="font-black text-red-600 text-lg">{score}</span>
            </div>
            <div className="flex justify-between">
              <span className="font-bold text-gray-700">Ukupni poeni</span>
              <span className="font-black text-green-600 text-xl">{totalScore}</span>
            </div>
          </div>

          {/* Fun fact */}
          <div className="bg-red-50 border border-red-100 rounded-xl p-4">
            <div className="text-xs font-bold text-red-500 uppercase tracking-wide mb-2">
              🌸 Znate li da...
            </div>
            <p className="text-sm text-gray-700 leading-relaxed text-left">
              {funFact}
            </p>
          </div>

          {/* Buttons */}
          <div className="flex flex-col gap-3">
            <Button3D variant="primary" size="lg" onClick={onPlayAgain} fullWidth>
              🔄 Igraj ponovo
            </Button3D>
            <Button3D variant="ghost" size="md" onClick={onMainMenu} fullWidth>
              🏠 Glavni meni
            </Button3D>
          </div>
        </div>
      </div>
    </div>
  );
}
