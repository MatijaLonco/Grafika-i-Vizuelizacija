import React from 'react';
import { Button3D } from '../components/Button3D';

interface MainMenuProps {
  onStart: () => void;
  onSoundSettings: () => void;
  onHowToPlay: () => void;
}

export function MainMenu({ onStart, onSoundSettings, onHowToPlay }: MainMenuProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-fade-in flex flex-col items-center gap-8 w-full max-w-sm">
        {/* Title */}
        <div className="text-center">
          <div className="text-6xl font-black text-red-600 tracking-tight drop-shadow-sm">
            カクロ
          </div>
          <div className="text-4xl font-black text-red-700 tracking-widest mt-1">
            KAKURO
          </div>
          <div className="mt-2 text-sm text-amber-700 font-medium tracking-wide">
            ✦ Japanska digitalna ukrstenica ✦
          </div>
        </div>

        {/* Decorative divider */}
        <div className="flex items-center gap-3 w-full">
          <div className="flex-1 h-px bg-gradient-to-r from-transparent to-red-300" />
          <div className="text-red-400 text-xl">⛩</div>
          <div className="flex-1 h-px bg-gradient-to-l from-transparent to-red-300" />
        </div>

        {/* Menu buttons */}
        <div className="flex flex-col gap-4 w-full">
          <Button3D variant="primary" size="xl" onClick={onStart} fullWidth>
            🎮 Igraj
          </Button3D>
          <Button3D variant="secondary" size="lg" onClick={onSoundSettings} fullWidth>
            🔊 Podešavanja zvuka
          </Button3D>
          <Button3D variant="ghost" size="lg" onClick={onHowToPlay} fullWidth>
            📖 Kako igrati
          </Button3D>
        </div>

        <div className="text-xs text-amber-600 opacity-60 text-center">
          Počasti japansku tradiciju logike i strpljenja
        </div>
      </div>
    </div>
  );
}
