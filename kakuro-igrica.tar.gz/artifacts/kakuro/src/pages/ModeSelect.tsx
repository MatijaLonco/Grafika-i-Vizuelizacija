import React from 'react';
import { Button3D } from '../components/Button3D';

interface ModeSelectProps {
  onSinglePlayer: () => void;
  onTwoPlayer: () => void;
  onBack: () => void;
}

export function ModeSelect({ onSinglePlayer, onTwoPlayer, onBack }: ModeSelectProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-fade-in w-full max-w-sm">
        <div className="flex items-center gap-3 mb-8">
          <Button3D variant="ghost" size="sm" onClick={onBack}>
            ← Nazad
          </Button3D>
          <h1 className="text-2xl font-black text-red-700">Odaberi mod</h1>
        </div>

        <div className="flex flex-col gap-5">
          <button
            className="btn-3d bg-red-600 text-white rounded-2xl p-6 text-left hover:bg-red-700"
            onClick={onSinglePlayer}
          >
            <div className="text-3xl mb-2">🎮</div>
            <div className="text-xl font-black">1 Igrac</div>
            <div className="text-sm opacity-80 mt-1">
              Rješavaj slagalicu sam, sakupljaj poene i bori se s tajmerom.
            </div>
          </button>

          <button
            className="btn-3d bg-sky-600 text-white rounded-2xl p-6 text-left hover:bg-sky-700"
            onClick={onTwoPlayer}
          >
            <div className="text-3xl mb-2">👥</div>
            <div className="text-xl font-black">2 Igraca</div>
            <div className="text-sm opacity-80 mt-1">
              Igrac 1 rješava, pa igrac 2 rješava istu slagalicu. Ko brže završi — pobijedi!
            </div>
          </button>
        </div>
      </div>
    </div>
  );
}
