import React from 'react';
import { Button3D } from '../components/Button3D';

interface HowToPlayProps {
  onBack: () => void;
}

export function HowToPlay({ onBack }: HowToPlayProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-start sakura-bg px-4 py-8">
      <div className="animate-fade-in w-full max-w-lg">
        <div className="flex items-center gap-3 mb-6">
          <Button3D variant="ghost" size="sm" onClick={onBack}>
            ← Nazad
          </Button3D>
          <h1 className="text-2xl font-black text-red-700">Kako igrati Kakuro</h1>
        </div>

        <div className="game-panel p-6 space-y-5 text-sm text-gray-700 leading-relaxed">
          <section>
            <h2 className="font-black text-red-600 text-base mb-2">🎯 Cilj igre</h2>
            <p>
              Popuni sve bijele ćelije brojevima od <strong>1 do 9</strong> tako da zbir
              svakog horizontalnog i vertikalnog niza odgovara zadanom broju (klue).
            </p>
          </section>

          <section>
            <h2 className="font-black text-red-600 text-base mb-2">📐 Pravila</h2>
            <ul className="list-none space-y-2">
              <li className="flex gap-2">
                <span className="text-red-500 font-bold">1.</span>
                Svaki broj u nizu mora biti <strong>različit</strong> (nema ponavljanja).
              </li>
              <li className="flex gap-2">
                <span className="text-red-500 font-bold">2.</span>
                Dozvoljeni su samo brojevi <strong>1 – 9</strong>.
              </li>
              <li className="flex gap-2">
                <span className="text-red-500 font-bold">3.</span>
                Crne ćelije s dijagonalnom linijom pokazuju zadane zbrojeve.
                Broj <em>gore lijevo</em> = zbir prema dolje; broj <em>dolje desno</em> = zbir prema desno.
              </li>
            </ul>
          </section>

          <section>
            <h2 className="font-black text-red-600 text-base mb-2">🖱️ Kontrole</h2>
            <ul className="list-none space-y-1">
              <li>• Klikni bijelo polje da ga odabereš</li>
              <li>• Upiši broj (1–9) s tastature ili koristite numpad</li>
              <li>• Stisni <kbd className="bg-gray-200 px-1 rounded">0</kbd> ili <kbd className="bg-gray-200 px-1 rounded">Del</kbd> za brisanje</li>
              <li>• Klikni polje – sva polja u istom redu i koloni se <strong>istaknu</strong></li>
            </ul>
          </section>

          <section>
            <h2 className="font-black text-red-600 text-base mb-2">💡 Hint i rješenje</h2>
            <ul className="list-none space-y-1">
              <li>• <strong>Hint</strong> – otkriva broj u odabranom polju, ali <strong>košta 1 poen</strong></li>
              <li>• <strong>Rješenje</strong> – otkriva cijelu slagalicu</li>
            </ul>
          </section>

          <section>
            <h2 className="font-black text-red-600 text-base mb-2">⭐ Bodovanje (1 igrac)</h2>
            <ul className="list-none space-y-1">
              <li>• Riješiš za ≤ 30 sek → <strong className="text-yellow-500">3 poena</strong> ⭐⭐⭐</li>
              <li>• Riješiš za ≤ 90 sek → <strong className="text-yellow-500">2 poena</strong> ⭐⭐</li>
              <li>• Riješiš za &gt; 90 sek → <strong className="text-yellow-500">1 poen</strong> ⭐</li>
              <li>• Svaki hint oduzima <strong>1 poen</strong> od konačnog rezultata</li>
            </ul>
          </section>

          <section>
            <h2 className="font-black text-red-600 text-base mb-2">👥 Mod 2 igrača</h2>
            <p>
              Igrac 1 rješava slagalicu. Kada završi, igrac 2 rješava <em>istu</em> slagalicu.
              Na kraju se usporede vremena — ko završi brže, <strong>pobijedi</strong>!
            </p>
          </section>
        </div>

        <div className="mt-6 flex justify-center">
          <Button3D variant="primary" size="lg" onClick={onBack}>
            Razumijem! Hajde da igramo 🎮
          </Button3D>
        </div>
      </div>
    </div>
  );
}
