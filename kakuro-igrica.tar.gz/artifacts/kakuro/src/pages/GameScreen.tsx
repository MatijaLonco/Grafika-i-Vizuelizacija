import React, { useCallback, useEffect, useReducer, useContext, useState } from 'react';
import { KakuroGrid } from '../components/KakuroGrid';
import { Button3D } from '../components/Button3D';
import { useTimer } from '../components/Timer';
import { createNewGame, setActiveCell, setCellValue, applyHint, revealSolution, calculateScore } from '../data/gameLogic';
import type { Difficulty, GameState } from '../types';
import { SoundCtx } from '../App';
import { playSfxNumber, playSfxComplete, playSfxHint, playSfxClick } from '../audio/music';

interface GameScreenProps {
  difficulty: Difficulty;
  onBack: () => void;
  onComplete: (seconds: number, score: number, hintsUsed: number) => void;
  playerLabel?: string;
  twoPlayerMode?: boolean;
}

function gameReducer(state: GameState, action: { type: string; payload?: unknown }): GameState {
  switch (action.type) {
    case 'SET_ACTIVE': {
      const { row, col } = action.payload as { row: number; col: number };
      return setActiveCell(state, row, col);
    }
    case 'SET_VALUE':
      return setCellValue(state, action.payload as number | null);
    case 'HINT':
      return applyHint(state);
    case 'REVEAL':
      return revealSolution(state);
    default:
      return state;
  }
}

export function GameScreen({ difficulty, onBack, onComplete, playerLabel, twoPlayerMode }: GameScreenProps) {
  const sound = useContext(SoundCtx);
  const [game, dispatch] = useReducer(gameReducer, null, () => createNewGame(difficulty));
  const [hintConfirm, setHintConfirm] = useState(false);
  const [revealConfirm, setRevealConfirm] = useState(false);
  const [completeCalled, setCompleteCalled] = useState(false);
  const { seconds } = useTimer(!game.isComplete);

  useEffect(() => {
    if (game.isComplete && !completeCalled) {
      setCompleteCalled(true);
      if (sound.sfxEnabled) playSfxComplete();
      const score = calculateScore(seconds, game.hintsUsed);
      onComplete(seconds, score, game.hintsUsed);
    }
  }, [game.isComplete, completeCalled, seconds, game.hintsUsed, onComplete, sound.sfxEnabled]);

  const handleCellClick = useCallback((row: number, col: number) => {
    if (!game.isComplete) {
      dispatch({ type: 'SET_ACTIVE', payload: { row, col } });
      if (sound.sfxEnabled) playSfxClick();
    }
  }, [game.isComplete, sound.sfxEnabled]);

  const handleNumberInput = useCallback((num: number | null) => {
    if (!game.isComplete) {
      dispatch({ type: 'SET_VALUE', payload: num });
      if (sound.sfxEnabled && num !== null) playSfxNumber();
    }
  }, [game.isComplete, sound.sfxEnabled]);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (game.isComplete) return;
      const num = parseInt(e.key);
      if (!isNaN(num) && num >= 1 && num <= 9) {
        dispatch({ type: 'SET_VALUE', payload: num });
        if (sound.sfxEnabled) playSfxNumber();
      } else if (e.key === '0' || e.key === 'Backspace' || e.key === 'Delete') {
        dispatch({ type: 'SET_VALUE', payload: null });
      }
    };
    window.addEventListener('keydown', handleKey);
    return () => window.removeEventListener('keydown', handleKey);
  }, [game.isComplete, sound.sfxEnabled]);

  const handleHint = () => {
    if (hintConfirm) {
      if (sound.sfxEnabled) playSfxHint();
      dispatch({ type: 'HINT' });
      setHintConfirm(false);
    } else {
      // If using a free hint, no confirmation needed
      if (game.freeHints > 0) {
        if (sound.sfxEnabled) playSfxHint();
        dispatch({ type: 'HINT' });
      } else {
        setHintConfirm(true);
        setTimeout(() => setHintConfirm(false), 3000);
      }
    }
  };

  const handleReveal = () => {
    if (revealConfirm) {
      dispatch({ type: 'REVEAL' });
      setRevealConfirm(false);
    } else {
      setRevealConfirm(true);
      setTimeout(() => setRevealConfirm(false), 3000);
    }
  };

  const mins = Math.floor(seconds / 60).toString().padStart(2, '0');
  const secs = (seconds % 60).toString().padStart(2, '0');

  const difficultyLabel = {
    easy: '🌸 Laki',
    medium: '🌿 Srednji',
    hard: '🌋 Teški',
  }[difficulty];

  const hasFreeHints = game.freeHints > 0;

  return (
    <div className="min-h-screen flex flex-col items-center sakura-bg px-2 py-4">
      {/* Header */}
      <div className="w-full max-w-2xl flex items-center justify-between mb-3 px-2">
        <Button3D variant="ghost" size="sm" onClick={onBack}>
          ← Nazad
        </Button3D>
        <div className="text-center">
          <div className="text-xs text-gray-500 font-medium">{difficultyLabel}</div>
          {playerLabel && (
            <div className="text-sm font-black text-sky-600">{playerLabel}</div>
          )}
        </div>
        <div className="game-panel px-4 py-2 text-center">
          <div className="timer-display">{mins}:{secs}</div>
          <div className="text-xs text-gray-400">tajmer</div>
        </div>
      </div>

      {/* Hints & score info bar */}
      <div className="w-full max-w-2xl mb-3 px-2">
        <div className="game-panel px-4 py-2 flex items-center justify-between gap-2">
          {/* Free hints counter */}
          <div className="flex items-center gap-2">
            <span className="text-sm font-bold text-gray-600">Besplatni hintovi:</span>
            <div className="flex gap-1">
              {[0, 1].map((i) => (
                <span
                  key={i}
                  className={`text-lg transition-all duration-300 ${i < game.freeHints ? 'opacity-100' : 'opacity-20 grayscale'}`}
                >
                  💡
                </span>
              ))}
            </div>
          </div>

          {/* Paid hints used */}
          {game.hintsUsed > 0 && (
            <div className="flex items-center gap-1 text-sm">
              <span className="text-red-500 font-bold">−{game.hintsUsed} poen{game.hintsUsed > 1 ? 'a' : ''}</span>
              <span className="text-gray-400">(plaćeni hint{game.hintsUsed > 1 ? 'ovi' : ''})</span>
            </div>
          )}

          {/* Score guide */}
          <div className="text-xs text-gray-400 hidden sm:block">
            ≤30s=⭐⭐⭐ · ≤90s=⭐⭐ · ostalo=⭐
          </div>
        </div>
      </div>

      {/* Grid */}
      <div className="game-panel p-4 mb-4 animate-pop-in">
        <KakuroGrid
          grid={game.grid}
          cellStates={game.cellStates}
          onCellClick={handleCellClick}
          isComplete={game.isComplete}
        />
      </div>

      {/* Number pad */}
      <div className="game-panel p-4 mb-4 w-full max-w-sm">
        <div className="grid grid-cols-5 gap-2">
          {[1, 2, 3, 4, 5, 6, 7, 8, 9].map((n) => (
            <button
              key={n}
              className="numpad-btn"
              onClick={() => handleNumberInput(n)}
              disabled={game.isComplete}
            >
              {n}
            </button>
          ))}
          <button
            className="numpad-btn bg-red-50 border-red-200 hover:bg-red-100"
            onClick={() => handleNumberInput(null)}
            disabled={game.isComplete}
          >
            ✕
          </button>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex gap-3 w-full max-w-sm justify-center">
        <Button3D
          variant={hintConfirm ? 'danger' : hasFreeHints ? 'accent' : 'secondary'}
          size="md"
          onClick={handleHint}
          disabled={game.isComplete}
        >
          {hintConfirm
            ? '❓ Potvrdi (−1 poen)'
            : hasFreeHints
              ? `💡 Hint (besplatno)`
              : '💡 Hint (−1 poen)'}
        </Button3D>
        <Button3D
          variant={revealConfirm ? 'danger' : 'ghost'}
          size="md"
          onClick={handleReveal}
        >
          {revealConfirm ? '👁 Sigurno?' : '👁 Rješenje'}
        </Button3D>
      </div>

      {/* Completion overlay */}
      {game.isComplete && (
        <div className="fixed inset-0 flex items-center justify-center bg-black/40 z-50">
          <div className="completion-overlay game-panel p-8 text-center mx-4 max-w-sm">
            <div className="text-5xl mb-3">🎉</div>
            <div className="text-2xl font-black text-red-600 mb-1">Kraj!</div>
            <div className="text-gray-600">Završeno za <strong>{mins}:{secs}</strong></div>
          </div>
        </div>
      )}
    </div>
  );
}
