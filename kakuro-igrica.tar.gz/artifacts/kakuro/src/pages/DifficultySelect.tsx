import React from 'react';
import { Button3D } from '../components/Button3D';
import type { Difficulty } from '../types';

interface DifficultySelectProps {
  onSelect: (d: Difficulty) => void;
  onBack: () => void;
  isTwoPlayer?: boolean;
}

const levels = [
  {
    value: 'easy' as Difficulty,
    label: 'Laki',
    emoji: '🌸',
    color: 'bg-green-500 hover:bg-green-600',
    desc: 'Manji grid, savršen za početnike. Idealno za učenje pravila.',
  },
  {
    value: 'medium' as Difficulty,
    label: 'Srednji',
    emoji: '🌿',
    color: 'bg-amber-500 hover:bg-amber-600',
    desc: 'Veći grid, zahtjeva malo više razmišljanja. Za iskusne igrače.',
  },
  {
    value: 'hard' as Difficulty,
    label: 'Teški',
    emoji: '🌋',
    color: 'bg-red-600 hover:bg-red-700',
    desc: 'Kompleksna slagalica koja testira vaše granice. Za eksperte!',
  },
];

export function DifficultySelect({ onSelect, onBack, isTwoPlayer }: DifficultySelectProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-fade-in w-full max-w-sm">
        <div className="flex items-center gap-3 mb-8">
          <Button3D variant="ghost" size="sm" onClick={onBack}>
            ← Nazad
          </Button3D>
          <h1 className="text-2xl font-black text-red-700">
            {isTwoPlayer ? '👥 Odaberi nivo' : 'Odaberi nivo'}
          </h1>
        </div>

        {isTwoPlayer && (
          <div className="mb-4 p-3 bg-sky-50 border border-sky-200 rounded-xl text-sm text-sky-700 text-center">
            Oba igraca rješavaju <strong>istu slagalicu</strong> — odaberi nivo za oboje!
          </div>
        )}

        <div className="flex flex-col gap-4">
          {levels.map((lvl) => (
            <button
              key={lvl.value}
              className={`btn-3d ${lvl.color} text-white rounded-2xl p-5 text-left`}
              onClick={() => onSelect(lvl.value)}
            >
              <div className="flex items-center gap-3">
                <span className="text-3xl">{lvl.emoji}</span>
                <div>
                  <div className="text-xl font-black">{lvl.label}</div>
                  <div className="text-sm opacity-85 mt-0.5">{lvl.desc}</div>
                </div>
              </div>
            </button>
          ))}
        </div>
      </div>
    </div>
  );
}
