import React from 'react';
import { Button3D } from '../components/Button3D';
import type { SoundSettings } from '../types';

interface SoundSettingsProps {
  settings: SoundSettings;
  onChange: (s: SoundSettings) => void;
  onBack: () => void;
}

export function SoundSettingsPage({ settings, onChange, onBack }: SoundSettingsProps) {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center sakura-bg px-4">
      <div className="animate-fade-in w-full max-w-sm">
        <div className="flex items-center gap-3 mb-6">
          <Button3D variant="ghost" size="sm" onClick={onBack}>
            ← Nazad
          </Button3D>
          <h1 className="text-2xl font-black text-red-700">🔊 Zvuk</h1>
        </div>

        <div className="game-panel p-6 space-y-6">
          {/* Music toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="font-bold text-gray-800">Muzika</div>
              <div className="text-xs text-gray-500">Pozadinska muzika</div>
            </div>
            <button
              className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${settings.musicEnabled ? 'bg-red-500' : 'bg-gray-300'}`}
              onClick={() => onChange({ ...settings, musicEnabled: !settings.musicEnabled })}
            >
              <span
                className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${settings.musicEnabled ? 'left-8' : 'left-1'}`}
              />
            </button>
          </div>

          {/* SFX toggle */}
          <div className="flex items-center justify-between">
            <div>
              <div className="font-bold text-gray-800">Zvučni efekti</div>
              <div className="text-xs text-gray-500">Zvukovi klikova i pobjede</div>
            </div>
            <button
              className={`relative w-14 h-7 rounded-full transition-colors duration-200 ${settings.sfxEnabled ? 'bg-red-500' : 'bg-gray-300'}`}
              onClick={() => onChange({ ...settings, sfxEnabled: !settings.sfxEnabled })}
            >
              <span
                className={`absolute top-1 w-5 h-5 rounded-full bg-white shadow transition-transform duration-200 ${settings.sfxEnabled ? 'left-8' : 'left-1'}`}
              />
            </button>
          </div>

          {/* Volume slider */}
          <div>
            <div className="flex justify-between mb-2">
              <span className="font-bold text-gray-800">Glasnoća</span>
              <span className="text-sm font-mono text-red-600">{settings.volume}%</span>
            </div>
            <input
              type="range"
              min={0}
              max={100}
              value={settings.volume}
              onChange={(e) => onChange({ ...settings, volume: Number(e.target.value) })}
              className="w-full accent-red-600 h-2 rounded-full"
            />
            <div className="flex justify-between text-xs text-gray-400 mt-1">
              <span>🔇</span>
              <span>🔊</span>
            </div>
          </div>
        </div>

        <div className="mt-6 flex justify-center">
          <Button3D variant="primary" size="lg" onClick={onBack}>
            Sačuvaj i nazad
          </Button3D>
        </div>
      </div>
    </div>
  );
}
