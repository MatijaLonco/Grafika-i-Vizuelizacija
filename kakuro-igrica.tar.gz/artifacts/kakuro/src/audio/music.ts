// Web Audio API – ambient Japanese pentatonic background music + SFX

let audioCtx: AudioContext | null = null;
let masterGain: GainNode | null = null;
let musicGain: GainNode | null = null;
let sfxGain: GainNode | null = null;
let scheduledNodes: AudioNode[] = [];
let scheduleTimer: ReturnType<typeof setTimeout> | null = null;
let isPlaying = false;

function getCtx(): AudioContext {
  if (!audioCtx) {
    audioCtx = new (window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext)();
    masterGain = audioCtx.createGain();
    masterGain.connect(audioCtx.destination);

    musicGain = audioCtx.createGain();
    musicGain.gain.value = 0.18;
    musicGain.connect(masterGain);

    sfxGain = audioCtx.createGain();
    sfxGain.gain.value = 0.4;
    sfxGain.connect(masterGain);
  }
  return audioCtx;
}

// Japanese pentatonic scale in Hz (C4-based: C D E G A C5 D5 E5 G5 A5)
const PENTA = [261.63, 293.66, 329.63, 392.0, 440.0, 523.25, 587.33, 659.25, 784.0, 880.0];

// Melodic patterns (indices into PENTA)
const PATTERNS = [
  [0, 2, 4, 3, 1, 0, 2, 4],
  [4, 3, 2, 0, 1, 2, 4, 5],
  [0, 1, 3, 4, 3, 1, 0, 2],
  [5, 4, 3, 2, 0, 1, 3, 5],
  [2, 4, 5, 4, 3, 2, 0, 1],
];

let patternIdx = 0;
let noteIdx = 0;

function scheduleNote(ctx: AudioContext, freq: number, startTime: number, duration: number) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();

  osc.type = 'triangle';
  osc.frequency.value = freq;

  // Softer overtone
  const osc2 = ctx.createOscillator();
  osc2.type = 'sine';
  osc2.frequency.value = freq * 2;

  const gain2 = ctx.createGain();
  gain2.gain.value = 0.15;

  osc.connect(gain);
  osc2.connect(gain2);
  gain.connect(musicGain!);
  gain2.connect(musicGain!);

  // Envelope: attack + sustain + release
  gain.gain.setValueAtTime(0, startTime);
  gain.gain.linearRampToValueAtTime(0.5, startTime + 0.04);
  gain.gain.setValueAtTime(0.5, startTime + duration - 0.12);
  gain.gain.linearRampToValueAtTime(0, startTime + duration);

  gain2.gain.setValueAtTime(0, startTime);
  gain2.gain.linearRampToValueAtTime(0.15, startTime + 0.04);
  gain2.gain.setValueAtTime(0.15, startTime + duration - 0.12);
  gain2.gain.linearRampToValueAtTime(0, startTime + duration);

  osc.start(startTime);
  osc.stop(startTime + duration);
  osc2.start(startTime);
  osc2.stop(startTime + duration);

  scheduledNodes.push(osc, osc2, gain, gain2);
}

function scheduleDroneNote(ctx: AudioContext, freq: number, startTime: number, duration: number) {
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.type = 'sine';
  osc.frequency.value = freq;
  osc.connect(gain);
  gain.connect(musicGain!);
  gain.gain.setValueAtTime(0, startTime);
  gain.gain.linearRampToValueAtTime(0.12, startTime + 0.5);
  gain.gain.setValueAtTime(0.12, startTime + duration - 0.5);
  gain.gain.linearRampToValueAtTime(0, startTime + duration);
  osc.start(startTime);
  osc.stop(startTime + duration);
  scheduledNodes.push(osc, gain);
}

const NOTE_DURATION = 0.55; // seconds per note
const LOOKAHEAD = 4.0;      // schedule 4 seconds ahead
const INTERVAL = 2000;      // re-schedule every 2s

function scheduleAhead() {
  if (!isPlaying || !audioCtx || !musicGain) return;

  const ctx = audioCtx;
  const now = ctx.currentTime;
  const pattern = PATTERNS[patternIdx % PATTERNS.length];

  // Schedule notes for LOOKAHEAD window
  let t = now;
  let count = 0;

  while (t < now + LOOKAHEAD && count < 20) {
    const pIdx = noteIdx % pattern.length;
    const freq = PENTA[pattern[pIdx]];

    // Occasionally skip a note for rhythmic interest
    if (Math.random() > 0.15) {
      scheduleNote(ctx, freq, t, NOTE_DURATION * 0.85);
    }

    // Add drone on pattern start
    if (pIdx === 0) {
      scheduleDroneNote(ctx, PENTA[0] / 2, t, NOTE_DURATION * 8);
    }

    t += NOTE_DURATION;
    noteIdx++;
    count++;

    if (noteIdx % pattern.length === 0) {
      patternIdx = (patternIdx + 1) % PATTERNS.length;
    }
  }

  if (isPlaying) {
    scheduleTimer = setTimeout(scheduleAhead, INTERVAL);
  }
}

export function startMusic(volume: number) {
  const ctx = getCtx();

  // Resume context if suspended (browser autoplay policy)
  if (ctx.state === 'suspended') {
    ctx.resume().catch(() => {});
  }

  if (isPlaying) {
    setMusicVolume(volume);
    return;
  }

  isPlaying = true;
  noteIdx = 0;
  patternIdx = Math.floor(Math.random() * PATTERNS.length);
  setMusicVolume(volume);
  scheduleAhead();
}

export function stopMusic() {
  isPlaying = false;
  if (scheduleTimer) {
    clearTimeout(scheduleTimer);
    scheduleTimer = null;
  }
  // Fade out
  if (musicGain && audioCtx) {
    musicGain.gain.setTargetAtTime(0, audioCtx.currentTime, 0.3);
    setTimeout(() => {
      if (musicGain) musicGain.gain.value = 0.18;
    }, 1500);
  }
}

export function setMusicVolume(pct: number) {
  if (!musicGain || !audioCtx) return;
  const vol = (pct / 100) * 0.25;
  musicGain.gain.setTargetAtTime(vol, audioCtx.currentTime, 0.1);
}

export function setMasterVolume(pct: number) {
  if (!masterGain || !audioCtx) return;
  masterGain.gain.setTargetAtTime(pct / 100, audioCtx.currentTime, 0.1);
}

// SFX

export function playSfxClick() {
  if (!sfxGain) return;
  try {
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(880, ctx.currentTime);
    osc.frequency.exponentialRampToValueAtTime(440, ctx.currentTime + 0.08);
    gain.gain.setValueAtTime(0.25, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.08);
    osc.connect(gain);
    gain.connect(sfxGain);
    osc.start();
    osc.stop(ctx.currentTime + 0.08);
  } catch {}
}

export function playSfxNumber() {
  if (!sfxGain) return;
  try {
    const ctx = getCtx();
    const osc = ctx.createOscillator();
    const gain = ctx.createGain();
    osc.type = 'sine';
    osc.frequency.value = 660;
    gain.gain.setValueAtTime(0.15, ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.06);
    osc.connect(gain);
    gain.connect(sfxGain);
    osc.start();
    osc.stop(ctx.currentTime + 0.06);
  } catch {}
}

export function playSfxComplete() {
  if (!sfxGain) return;
  try {
    const ctx = getCtx();
    const notes = [523.25, 659.25, 784.0, 1046.5];
    notes.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.value = freq;
      const t = ctx.currentTime + i * 0.15;
      gain.gain.setValueAtTime(0, t);
      gain.gain.linearRampToValueAtTime(0.4, t + 0.04);
      gain.gain.linearRampToValueAtTime(0, t + 0.35);
      osc.connect(gain);
      gain.connect(sfxGain);
      osc.start(t);
      osc.stop(t + 0.35);
    });
  } catch {}
}

export function playSfxHint() {
  if (!sfxGain) return;
  try {
    const ctx = getCtx();
    const freqs = [440, 554.37, 659.25];
    freqs.forEach((freq, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.type = 'sine';
      osc.frequency.value = freq;
      const t = ctx.currentTime + i * 0.1;
      gain.gain.setValueAtTime(0.2, t);
      gain.gain.exponentialRampToValueAtTime(0.001, t + 0.18);
      osc.connect(gain);
      gain.connect(sfxGain);
      osc.start(t);
      osc.stop(t + 0.18);
    });
  } catch {}
}
