import type { PuzzleGrid, GameCellState, GameState, Difficulty } from '../types';
import { getRandomPuzzle } from './puzzles';

export function createInitialCellStates(grid: PuzzleGrid): (GameCellState | null)[][] {
  return grid.map((row) =>
    row.map((cell) => {
      if (cell.type !== 'white') return null;
      return {
        value: null,
        highlighted: false,
        isActive: false,
        isCorrect: null,
        isHinted: false,
      };
    })
  );
}

export function createNewGame(difficulty: Difficulty): GameState {
  const puzzle = getRandomPuzzle(difficulty);
  return {
    puzzleId: puzzle.id,
    difficulty,
    grid: puzzle.grid,
    cellStates: createInitialCellStates(puzzle.grid),
    activeCell: null,
    isComplete: false,
    hintsUsed: 0,
    freeHints: 2,
  };
}

export function getRunCells(
  grid: PuzzleGrid,
  row: number,
  col: number
): { horizontal: [number, number][]; vertical: [number, number][] } {
  const rows = grid.length;
  const cols = grid[0].length;

  // Find horizontal run
  let hLeft = col;
  while (hLeft > 0 && grid[row][hLeft - 1].type === 'white') hLeft--;
  let hRight = col;
  while (hRight < cols - 1 && grid[row][hRight + 1].type === 'white') hRight++;
  const horizontal: [number, number][] = [];
  for (let c = hLeft; c <= hRight; c++) {
    if (grid[row][c].type === 'white') horizontal.push([row, c]);
  }

  // Find vertical run
  let vTop = row;
  while (vTop > 0 && grid[vTop - 1][col].type === 'white') vTop--;
  let vBottom = row;
  while (vBottom < rows - 1 && grid[vBottom + 1][col].type === 'white') vBottom++;
  const vertical: [number, number][] = [];
  for (let r = vTop; r <= vBottom; r++) {
    if (grid[r][col].type === 'white') vertical.push([r, col]);
  }

  return { horizontal, vertical };
}

export function setActiveCell(
  state: GameState,
  row: number,
  col: number
): GameState {
  if (state.grid[row][col].type !== 'white') return state;

  const { horizontal, vertical } = getRunCells(state.grid, row, col);
  const allHighlighted = new Set([...horizontal, ...vertical].map(([r, c]) => `${r},${c}`));

  const newCellStates = state.cellStates.map((rowArr, r) =>
    rowArr.map((cell, c) => {
      if (!cell) return null;
      return {
        ...cell,
        isActive: r === row && c === col,
        highlighted: allHighlighted.has(`${r},${c}`) && !(r === row && c === col),
      };
    })
  );

  return { ...state, cellStates: newCellStates, activeCell: [row, col] };
}

export function setCellValue(state: GameState, value: number | null): GameState {
  if (!state.activeCell) return state;
  const [row, col] = state.activeCell;
  const cell = state.cellStates[row][col];
  if (!cell) return state;

  const newCellStates = state.cellStates.map((rowArr, r) =>
    rowArr.map((c, colIdx) => {
      if (r === row && colIdx === col) {
        return { ...c!, value, isCorrect: null };
      }
      return c;
    })
  );

  const newState = { ...state, cellStates: newCellStates };
  return checkCompletion(newState);
}

export function checkCompletion(state: GameState): GameState {
  const grid = state.grid;
  const cellStates = state.cellStates;

  let allFilled = true;
  let allCorrect = true;

  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      const gridCell = grid[r][c];
      const cellState = cellStates[r][c];
      if (gridCell.type === 'white' && cellState) {
        if (cellState.value === null) {
          allFilled = false;
          allCorrect = false;
        } else if (cellState.value !== (gridCell as { type: 'white'; solution: number }).solution) {
          allCorrect = false;
        }
      }
    }
  }

  if (allFilled && allCorrect) {
    return { ...state, isComplete: true };
  }

  return state;
}

export function applyHint(state: GameState): GameState {
  if (!state.activeCell) {
    // Find first unfilled cell
    for (let r = 0; r < state.grid.length; r++) {
      for (let c = 0; c < state.grid[r].length; c++) {
        if (state.grid[r][c].type === 'white' && state.cellStates[r][c]?.value === null) {
          const hintedState = setActiveCell(state, r, c);
          return applyHintToActive(hintedState);
        }
      }
    }
    return state;
  }
  return applyHintToActive(state);
}

function applyHintToActive(state: GameState): GameState {
  if (!state.activeCell) return state;
  const [row, col] = state.activeCell;
  const gridCell = state.grid[row][col];
  if (gridCell.type !== 'white') return state;

  const solution = (gridCell as { type: 'white'; solution: number }).solution;

  const newCellStates = state.cellStates.map((rowArr, r) =>
    rowArr.map((cell, c) => {
      if (r === row && c === col) {
        return { ...cell!, value: solution, isHinted: true, isCorrect: true };
      }
      return cell;
    })
  );

  // Use a free hint first; only charge (hintsUsed++) when free ones are exhausted
  const usingFree = state.freeHints > 0;
  const newState = {
    ...state,
    cellStates: newCellStates,
    freeHints: usingFree ? state.freeHints - 1 : state.freeHints,
    hintsUsed: usingFree ? state.hintsUsed : state.hintsUsed + 1,
  };
  return checkCompletion(newState);
}

export function revealSolution(state: GameState): GameState {
  const newCellStates = state.cellStates.map((rowArr, r) =>
    rowArr.map((cell, c) => {
      if (!cell) return null;
      const gridCell = state.grid[r][c];
      if (gridCell.type !== 'white') return cell;
      const solution = (gridCell as { type: 'white'; solution: number }).solution;
      return { ...cell, value: solution, isHinted: true, isCorrect: true };
    })
  );

  return { ...state, cellStates: newCellStates, isComplete: true };
}

export function calculateScore(seconds: number, hintsUsed: number): number {
  let base = 1;
  if (seconds <= 30) base = 3;
  else if (seconds <= 90) base = 2;
  else base = 1;

  const score = Math.max(0, base - hintsUsed);
  return score;
}

export function moveToNextCell(state: GameState, direction: 'next' | 'prev'): GameState {
  if (!state.activeCell) return state;
  const [row, col] = state.activeCell;
  const grid = state.grid;

  const whiteCells: [number, number][] = [];
  for (let r = 0; r < grid.length; r++) {
    for (let c = 0; c < grid[r].length; c++) {
      if (grid[r][c].type === 'white') whiteCells.push([r, c]);
    }
  }

  const currentIdx = whiteCells.findIndex(([r, c]) => r === row && c === col);
  if (currentIdx === -1) return state;

  const nextIdx = direction === 'next'
    ? (currentIdx + 1) % whiteCells.length
    : (currentIdx - 1 + whiteCells.length) % whiteCells.length;

  const [nr, nc] = whiteCells[nextIdx];
  return setActiveCell(state, nr, nc);
}
