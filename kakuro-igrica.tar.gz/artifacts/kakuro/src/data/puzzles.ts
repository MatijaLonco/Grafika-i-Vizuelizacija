import type { Puzzle, PuzzleGrid } from '../types';

// Helper to create cells
const B = (): { type: 'block' } => ({ type: 'block' });
const C = (right?: number, down?: number): { type: 'clue'; right?: number; down?: number } => ({
  type: 'clue',
  ...(right !== undefined ? { right } : {}),
  ...(down !== undefined ? { down } : {}),
});
const W = (solution: number): { type: 'white'; solution: number } => ({
  type: 'white',
  solution,
});

// ─────────────────────── EASY PUZZLES (5×5 grid) ───────────────────────
// Easy 1: 7 white cells, verified solution
const easyGrid1: PuzzleGrid = [
  [B(), B(),         C(undefined,12), C(undefined,7), B()],
  [B(), C(3,9),      W(1),            W(2),           B()],
  [C(12), W(3),      W(4),            W(5),           B()],
  [C(13), W(6),      W(7),            B(),            B()],
  [B(), B(),         B(),             B(),            B()],
];

// Easy 2: different numbers, same shape
const easyGrid2: PuzzleGrid = [
  [B(), B(),         C(undefined,14), C(undefined,11), B()],
  [B(), C(8,12),     W(3),            W(5),            B()],
  [C(12), W(4),      W(2),            W(6),            B()],
  [C(17), W(8),      W(9),            B(),             B()],
  [B(), B(),         B(),             B(),             B()],
];

// Easy 3: another variation
const easyGrid3: PuzzleGrid = [
  [B(), B(),         C(undefined,18), C(undefined,13), B()],
  [B(), C(11,7),     W(7),            W(4),            B()],
  [C(17), W(5),      W(3),            W(9),            B()],
  [C(10), W(2),      W(8),            B(),             B()],
  [B(), B(),         B(),             B(),             B()],
];

// ─────────────────────── MEDIUM PUZZLES (6×6 grid) ───────────────────────
// Medium 1: verified solution
const mediumGrid1: PuzzleGrid = [
  [B(), B(),          C(undefined,13), C(undefined,25), C(undefined,12), B()],
  [B(), C(12,17),     W(3),            W(7),            W(2),            B()],
  [C(16), W(5),       W(1),            W(6),            W(4),            B()],
  [C(25), W(8),       W(2),            W(9),            W(6),            B()],
  [C(14), W(4),       W(7),            W(3),            B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B()],
];

// Medium 2: verified solution
const mediumGrid2: PuzzleGrid = [
  [B(), B(),          C(undefined,25), C(undefined,18), C(undefined,9),  B()],
  [B(), C(14,12),     W(6),            W(3),            W(5),            B()],
  [C(18), W(7),       W(2),            W(8),            W(1),            B()],
  [C(21), W(4),       W(9),            W(5),            W(3),            B()],
  [C(11), W(1),       W(8),            W(2),            B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B()],
];

// Medium 3: verified solution
const mediumGrid3: PuzzleGrid = [
  [B(), B(),          C(undefined,24), C(undefined,19), C(undefined,13), B()],
  [B(), C(14,11),     W(4),            W(9),            W(1),            B()],
  [C(20), W(2),       W(7),            W(3),            W(8),            B()],
  [C(16), W(6),       W(5),            W(1),            W(4),            B()],
  [C(17), W(3),       W(8),            W(6),            B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B()],
];

// ─────────────────────── HARD PUZZLES (7×7 grid) ───────────────────────
// Hard 1: verified solution
const hardGrid1: PuzzleGrid = [
  [B(), B(),          C(undefined,19), C(undefined,32), C(undefined,20), C(undefined,19), B()],
  [B(), C(16,26),     W(3),            W(8),            W(1),            W(4),            B()],
  [C(29), W(7),       W(2),            W(5),            W(9),            W(6),            B()],
  [C(25), W(5),       W(4),            W(6),            W(3),            W(7),            B()],
  [C(27), W(8),       W(1),            W(9),            W(7),            W(2),            B()],
  [C(19), W(6),       W(9),            W(4),            B(),             B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B(),             B()],
];

// Hard 2: verified solution
const hardGrid2: PuzzleGrid = [
  [B(), B(),          C(undefined,32), C(undefined,25), C(undefined,26), C(undefined,21), B()],
  [B(), C(19,19),     W(6),            W(4),            W(7),            W(2),            B()],
  [C(26), W(3),       W(8),            W(1),            W(5),            W(9),            B()],
  [C(28), W(7),       W(2),            W(9),            W(6),            W(4),            B()],
  [C(31), W(5),       W(9),            W(3),            W(8),            W(6),            B()],
  [C(19), W(4),       W(7),            W(8),            B(),             B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B(),             B()],
];

// Hard 3: verified solution
const hardGrid3: PuzzleGrid = [
  [B(), B(),          C(undefined,24), C(undefined,27), C(undefined,24), C(undefined,21), B()],
  [B(), C(21,21),     W(1),            W(9),            W(3),            W(8),            B()],
  [C(22), W(4),       W(7),            W(2),            W(6),            W(3),            B()],
  [C(30), W(9),       W(5),            W(7),            W(8),            W(1),            B()],
  [C(30), W(2),       W(8),            W(4),            W(7),            W(9),            B()],
  [C(14), W(6),       W(3),            W(5),            B(),             B(),             B()],
  [B(), B(),          B(),             B(),             B(),             B(),             B()],
];

export const PUZZLES: Record<string, { easy: Puzzle[]; medium: Puzzle[]; hard: Puzzle[] }> = {
  all: {
    easy: [
      { id: 'easy-1', grid: easyGrid1 },
      { id: 'easy-2', grid: easyGrid2 },
      { id: 'easy-3', grid: easyGrid3 },
    ],
    medium: [
      { id: 'medium-1', grid: mediumGrid1 },
      { id: 'medium-2', grid: mediumGrid2 },
      { id: 'medium-3', grid: mediumGrid3 },
    ],
    hard: [
      { id: 'hard-1', grid: hardGrid1 },
      { id: 'hard-2', grid: hardGrid2 },
      { id: 'hard-3', grid: hardGrid3 },
    ],
  },
};

export function getRandomPuzzle(difficulty: 'easy' | 'medium' | 'hard'): Puzzle {
  const list = PUZZLES.all[difficulty];
  return list[Math.floor(Math.random() * list.length)];
}
