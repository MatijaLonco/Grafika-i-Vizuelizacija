export type Screen =
  | 'main-menu'
  | 'mode-select'
  | 'difficulty-select'
  | 'how-to-play'
  | 'sound-settings'
  | 'game'
  | 'game-complete'
  | 'two-player-p1'
  | 'two-player-p2'
  | 'two-player-result';

export type Difficulty = 'easy' | 'medium' | 'hard';

export type PuzzleCellType = 'block' | 'clue' | 'white';

export interface ClueCell {
  type: 'clue';
  right?: number;
  down?: number;
}

export interface WhiteCell {
  type: 'white';
  solution: number;
}

export interface BlockCell {
  type: 'block';
}

export type PuzzleCell = ClueCell | WhiteCell | BlockCell;

export type PuzzleGrid = PuzzleCell[][];

export interface Puzzle {
  id: string;
  grid: PuzzleGrid;
}

export interface GameCellState {
  value: number | null;
  highlighted: boolean;
  isActive: boolean;
  isCorrect: boolean | null;
  isHinted: boolean;
}

export interface GameState {
  puzzleId: string;
  difficulty: Difficulty;
  grid: PuzzleGrid;
  cellStates: (GameCellState | null)[][];
  activeCell: [number, number] | null;
  isComplete: boolean;
  hintsUsed: number;   // paid hints only (cost 1 point each)
  freeHints: number;   // free hint credits (start at 2)
}

export interface SoundSettings {
  musicEnabled: boolean;
  sfxEnabled: boolean;
  volume: number;
}

export interface AppState {
  screen: Screen;
  difficulty: Difficulty | null;
  soundSettings: SoundSettings;
  currentGame: GameState | null;
  player1Time: number | null;
  player2Time: number | null;
  player1HintsUsed: number;
  player2HintsUsed: number;
}
